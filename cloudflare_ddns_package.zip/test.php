<?php
echo "Cloudflare DDNS 測試頁面<br>";
echo "伺服器 IP: " . $_SERVER['SERVER_ADDR'] . "<br>";
echo "訪客 IP: " . $_SERVER['REMOTE_ADDR'];
?>
